package com.example.task;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class view extends AppCompatActivity {
    EditText task, description;
    CheckBox chkstatus;
    Button view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        view = findViewById(R.id.view1);
        task =findViewById(R.id.task);
        description = findViewById(R.id.describe);
        chkstatus = findViewById(R.id.chkstatus);

        SharedPreferences sd =this.getSharedPreferences("Task", MODE_PRIVATE);
        SharedPreferences.Editor edit =sd.edit();
//edit.clear();
        task.setText(sd.getString("task",null));
        description.setText(sd.getString("description",null));
        Boolean status=sd.getBoolean("status", false);

        if(status==true){
            chkstatus.setChecked(true);
//            view.setClickable(true);

        }

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sd = getSharedPreferences("Task", MODE_PRIVATE);
                SharedPreferences.Editor edit = sd.edit();
                edit.putString("task", task.getText().toString());
                edit.putString("description", description.getText().toString());

//            Boolean login =true;
                if (chkstatus.isChecked()) {
                    edit.putBoolean("status", true);
                }else {

                    edit.putBoolean("status", false);
                }
                edit.commit();
                Toast.makeText(view.this, "Your task Save Success fully", Toast.LENGTH_SHORT).show();
                Intent register = new Intent(getApplicationContext(), home.class);
                startActivity(register);
            }
        });
    }
}
