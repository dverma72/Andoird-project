package com.example.task;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class home extends AppCompatActivity {
TextView user_name ,active_status;
ImageButton add, view, delete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        active_status= findViewById(R.id.txtactive);
        add=findViewById(R.id.add);
        view =findViewById(R.id.view);
        delete = findViewById(R.id.delete);
        user_name=findViewById(R.id.user_name);
        user_name.setText("Welcome "+getIntent().getStringExtra("user_name"));
        Log.d("user",user_name.toString());



        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(getApplicationContext(), add.class);
                startActivity(home);
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(getApplicationContext(), view.class);
                startActivity(home);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home = new Intent(getApplicationContext(), delete.class);
                startActivity(home);
            }
        });

    }
}