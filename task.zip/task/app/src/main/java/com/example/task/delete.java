package com.example.task;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class delete extends AppCompatActivity {
        EditText task, description;
        CheckBox chkstatus;
        Button delete;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_delete);
            delete = findViewById(R.id.delete);
            task =findViewById(R.id.task);
            description = findViewById(R.id.describe);
            chkstatus = findViewById(R.id.chkstatus);

            SharedPreferences sd =this.getSharedPreferences("Task", MODE_PRIVATE);
            SharedPreferences.Editor edit =sd.edit();
//edit.clear();
            task.setText(sd.getString("task",null));
            description.setText(sd.getString("description",null));
            Boolean status=sd.getBoolean("status", false);

            if(status==true){

                chkstatus.setChecked(true);
            }
            if(status==false){

                Intent register = new Intent(getApplicationContext(), home.class);
                startActivity(register);
                Toast.makeText(delete.this, "Your task is not Completed", Toast.LENGTH_SHORT).show();

            }

            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences preferences = getSharedPreferences("Task", 0);
                    preferences.edit().remove("task").commit();
                    preferences.edit().remove("description").commit();
                    preferences.edit().remove("status").commit();


                    task.setText("");
                    description.setText("");
                    Toast.makeText(delete.this, "Your task Deleted Success fully", Toast.LENGTH_SHORT).show();
                    Intent register = new Intent(getApplicationContext(), home.class);
                    startActivity(register);
                }
            });
        }
    }


