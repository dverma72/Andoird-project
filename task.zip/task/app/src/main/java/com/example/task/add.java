package com.example.task;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class add extends AppCompatActivity {
EditText task, description;
CheckBox chkstatus;
Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
save = findViewById(R.id.add);
        task =findViewById(R.id.task);
        description = findViewById(R.id.describe);
        chkstatus = findViewById(R.id.chkstatus);


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (task.getText().toString().trim().equals("")) {
                    task.setError("Please enter your Task");
                }
                if (description.getText().toString().trim().equals("")) {
                    description.setError("Please enter your Task");
                }
                SharedPreferences sd =getSharedPreferences("Task", MODE_PRIVATE);
                SharedPreferences.Editor edit =sd.edit();
                edit.putString("task",task.getText().toString());
                edit.putString("description",description.getText().toString());

//            Boolean login =true;
                if(chkstatus.isChecked()) {
                    edit.putBoolean("status", true);
                }
                edit.commit();

                Toast.makeText(add.this, "Your task save Success fully", Toast.LENGTH_SHORT).show();
                task.setText("");
                description.setText("");
                Intent register = new Intent(getApplicationContext(), home.class);
                startActivity(register);
            }
        });


    }
}